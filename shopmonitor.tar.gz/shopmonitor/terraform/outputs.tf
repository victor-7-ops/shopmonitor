output "instance_public_ip" {
  description = "Public IP of the ShopMonitor server"
  value       = aws_instance.shopmonitor.public_ip
}

output "instance_id" {
  description = "EC2 instance ID"
  value       = aws_instance.shopmonitor.id
}

output "security_group_id" {
  description = "Security group ID"
  value       = aws_security_group.shopmonitor.id
}

output "vpc_id" {
  description = "VPC ID"
  value       = aws_vpc.main.id
}

output "ssh_command" {
  description = "SSH command to connect to the server"
  value       = "ssh -i ~/.ssh/<your-key>.pem ubuntu@${aws_instance.shopmonitor.public_ip}"
}
